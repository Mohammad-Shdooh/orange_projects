let username =document.getElementById('userName');
let pass =document.getElementById('password').textContent;
let btn = document.getElementById('submit');

function user() { 
    let x=document.createElement('div') ; 
    let txt =document.createTextNode(username.innerText); 
    x.appendChild(txt) ;
    document.body.appendChild(x); 
}

btn.onclick = user();